<?php
include('../config/db.php');

// Validar que los campos no estén vacíos
if (empty($_POST['pregunta1']) || empty($_POST['pregunta2']) || empty($_POST['pregunta3']) ||
    empty($_POST['pregunta4']) || empty($_POST['pregunta5']) || empty($_POST['pregunta6'])) {
    echo "Todos los campos son requeridos.";
    exit();
}

// Obtener los datos del formulario
$mascota_id = $_POST['mascota_id'];
$nombre_mascota = $_POST['nombre_mascota'];
$pregunta1 = $_POST['pregunta1'];
$pregunta2 = $_POST['pregunta2'];
$pregunta3 = $_POST['pregunta3'];
$pregunta4 = $_POST['pregunta4'];
$pregunta5 = $_POST['pregunta5'];
$pregunta6 = $_POST['pregunta6'];

// Insertar los datos en la base de datos (suponiendo que existe una tabla 'encuestas')
$sql = "INSERT INTO Encuestas (mascota_id, nombre_mascota, pregunta1, pregunta2, pregunta3, pregunta4, pregunta5, pregunta6)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssss", $mascota_id, $nombre_mascota, $pregunta1, $pregunta2, $pregunta3, $pregunta4, $pregunta5, $pregunta6);

// Ejecutar la consulta
if ($stmt->execute()) {
    // Encuesta enviada exitosamente
    header("Location: ../index.php?success=1");
    exit();
} else {
    echo "Error al enviar la encuesta: " . $stmt->error;
    exit();
}
?>
