<?php include('../includes/header.php'); ?>
<?php include('../includes/navbar.php'); ?>

<div class="container mt-5">
    <h1 class="text-center mb-5 text-uppercase">Panel de Gestión</h1>

    <div class="row justify-content-center">
        <!-- Card 1: Gestión de Usuarios -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-primary">
                <div class="card-body text-center">
                    <h5 class="card-title mb-3"><i class="fas fa-users fa-3x text-primary"></i></h5>
                    <h4 class="card-text">Gestión de Usuarios</h4>
                    <p class="text-muted">Administra los usuarios de la plataforma.</p>
                    <a href="panel_admin/gestion_usuarios.php" class="btn btn-dark btn-lg btn-block mt-3">
                        <i class="fas fa-cogs"></i> Ir a la Gestión
                    </a>
                </div>
            </div>
        </div>

        <!-- Card 2: Gestión de Mascotas -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-success">
                <div class="card-body text-center">
                    <h5 class="card-title mb-3"><i class="fas fa-paw fa-3x text-success"></i></h5>
                    <h4 class="card-text">Gestión de Mascotas</h4>
                    <p class="text-muted">Administra y visualiza las mascotas disponibles.</p>
                    <a href="panel_admin/gestion_mascotas.php" class="btn btn-success btn-lg btn-block mt-3">
                        <i class="fas fa-cogs"></i> Ir a la Gestión
                    </a>
                </div>
            </div>
        </div>

        <!-- Card 3: Reportes y Estadísticas -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-warning">
                <div class="card-body text-center">
                    <h5 class="card-title mb-3"><i class="fas fa-chart-bar fa-3x text-warning"></i></h5>
                    <h4 class="card-text">Reportes y Estadísticas</h4>
                    <p class="text-muted">Consulta reportes detallados sobre el sistema.</p>
                    <a href="panel_admin/reportes_estadisticas.php" class="btn btn-warning btn-lg btn-block mt-3">
                        <i class="fas fa-cogs"></i> Ver Reportes
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>
