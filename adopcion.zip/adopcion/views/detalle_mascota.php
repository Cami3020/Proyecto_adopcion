<?php 
include('../includes/header.php'); 
include('../includes/navbar.php');

// Definir un arreglo con los detalles de las mascotas
$mascotas = [
    'M001' => [
        'nombre' => 'Fido',
        'edad' => 3,
        'raza' => 'Labrador',
        'personalidad' => 'Amigable y juguetón.',
        'estado' => 'Disponible',
        'detalles' => 'Fido es un perro activo que necesita un hogar donde pueda jugar mucho.',
        'foto' => 'perro1.jpeg',
        'refugio_id' => 'R001'
    ],
    'M002' => [
        'nombre' => 'Michi',
        'edad' => 2,
        'raza' => 'Persa',
        'personalidad' => 'Cariñoso y tranquilo.',
        'estado' => 'Disponible',
        'detalles' => 'Michi es un gato tranquilo que disfruta de largos ratos de siesta.',
        'foto' => 'gato1.jpeg',
        'refugio_id' => 'R001'
    ],
    'M003' => [
        'nombre' => 'Rex',
        'edad' => 4,
        'raza' => 'Pitbull',
        'personalidad' => 'Energético y juguetón.',
        'estado' => 'Disponible',
        'detalles' => 'Rex es un perro muy energético que necesita un dueño que lo saque a pasear frecuentemente.',
        'foto' => 'perro2.jpeg',
        'refugio_id' => 'R002'
    ],
    'M004' => [
        'nombre' => 'Luna',
        'edad' => 1,
        'raza' => 'Siamés',
        'personalidad' => 'Curiosa y juguetona.',
        'estado' => 'Disponible',
        'detalles' => 'Luna es una gata juguetona que ama perseguir pelotas y explorar.',
        'foto' => 'gato2.jpeg',
        'refugio_id' => 'R002'
    ],
    'M005' => [
        'nombre' => 'Max',
        'edad' => 5,
        'raza' => 'Rottweiler',
        'personalidad' => 'Fiel y protector.',
        'estado' => 'Disponible',
        'detalles' => 'Max es un perro leal que siempre está pendiente de su dueño.',
        'foto' => 'perro3.jpeg',
        'refugio_id' => 'R003'
    ],
    'M006' => [
        'nombre' => 'Cleo',
        'edad' => 3,
        'raza' => 'Bengalí',
        'personalidad' => 'Independiente y activo.',
        'estado' => 'Disponible',
        'detalles' => 'Cleo es un gato juguetón que disfruta de la compañía pero también es muy independiente.',
        'foto' => 'gato3.jpeg',
        'refugio_id' => 'R003'
    ]
];

// Obtener el ID de la mascota desde la URL
$mascota_id = $_GET['id'];

// Verificar si el ID existe en el arreglo de mascotas
if (isset($mascotas[$mascota_id])) {
    $mascota = $mascotas[$mascota_id];
} else {
    echo "<p>La mascota no fue encontrada.</p>";
    exit();
}
?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Detalles de la Mascota</h2>
    <div class="row">
        <div class="col-md-6">
            <img src="../img/<?php echo $mascota['foto']; ?>" class="img-fluid" alt="Foto de <?php echo $mascota['nombre']; ?>">
        </div>
        <div class="col-md-6">
            <h3><?php echo $mascota['nombre']; ?></h3>
            <p><strong>Edad:</strong> <?php echo $mascota['edad']; ?> años</p>
            <p><strong>Raza:</strong> <?php echo $mascota['raza']; ?></p>
            <p><strong>Personalidad:</strong> <?php echo $mascota['personalidad']; ?></p>
            <p><strong>Estado:</strong> <?php echo $mascota['estado']; ?></p>
            <p><strong>Detalles:</strong> <?php echo $mascota['detalles']; ?></p>
            <!-- Botón de Adoptar -->
            <a href="encuesta_adopcion.php?id=<?php echo $mascota_id; ?>" class="btn btn-success">
                Adoptame
            </a>
        </div>
    </div>
</div>

<?php 
include('../includes/footer.php'); 
?>
