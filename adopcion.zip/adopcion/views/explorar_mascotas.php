<?php include('../includes/header.php'); ?>
<?php include('../includes/navbar.php'); ?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Mascotas Disponibles</h2>
    <div class="row">
        <!-- Ejemplo de una tarjeta de perro -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <img src="../img/perro1.jpeg" class="card-img-top mascota-img" alt="Perro">
                <div class="card-body">
                    <h5 class="card-title">Fido</h5>
                    <p class="card-text">Un perro amigable en busca de un hogar amoroso.</p>
                    <a href="detalle_mascota.php?id=M001" class="btn btn-primary">
                        <i class="bi bi-info-circle"></i> Ver Detalles
                    </a>
                </div>
            </div>
        </div>
        <!-- Ejemplo de una tarjeta de gato -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <img src="../img/gato1.jpeg" class="card-img-top mascota-img" alt="Gato">
                <div class="card-body">
                    <h5 class="card-title">Michi</h5>
                    <p class="card-text">Un gato cariñoso que disfruta de largas siestas.</p>
                    <a href="detalle_mascota.php?id=M002" class="btn btn-primary">
                        <i class="bi bi-info-circle"></i> Ver Detalles
                    </a>
                </div>
            </div>
        </div>
        <!-- Nuevo perro -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <img src="../img/perro2.jpeg" class="card-img-top mascota-img" alt="Perro">
                <div class="card-body">
                    <h5 class="card-title">Rex</h5>
                    <p class="card-text">Un perro energético que ama los paseos y jugar.</p>
                    <a href="detalle_mascota.php?id=M003" class="btn btn-primary">
                        <i class="bi bi-info-circle"></i> Ver Detalles
                    </a>
                </div>
            </div>
        </div>
        <!-- Nuevo gato -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <img src="../img/gato2.jpeg" class="card-img-top mascota-img" alt="Gato">
                <div class="card-body">
                    <h5 class="card-title">Luna</h5>
                    <p class="card-text">Una gata juguetona que ama perseguir pelotas.</p>
                    <a href="detalle_mascota.php?id=M004" class="btn btn-primary">
                        <i class="bi bi-info-circle"></i> Ver Detalles
                    </a>
                </div>
            </div>
        </div>
        <!-- Otro perro -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <img src="../img/perro3.jpeg" class="card-img-top mascota-img" alt="Perro">
                <div class="card-body">
                    <h5 class="card-title">Bruno</h5>
                    <p class="card-text">Un perro tranquilo que busca una familia amable.</p>
                    <a href="detalle_mascota.php?id=M005" class="btn btn-primary">
                        <i class="bi bi-info-circle"></i> Ver Detalles
                    </a>
                </div>
            </div>
        </div>
        <!-- Otro gato -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <img src="../img/gato3.jpeg" class="card-img-top mascota-img" alt="Gato">
                <div class="card-body">
                    <h5 class="card-title">Simba</h5>
                    <p class="card-text">Un gato curioso que ama explorar su entorno.</p>
                    <a href="detalle_mascota.php?id=M006" class="btn btn-primary">
                        <i class="bi bi-info-circle"></i> Ver Detalles
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>
