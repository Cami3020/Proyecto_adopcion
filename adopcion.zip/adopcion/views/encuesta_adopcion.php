<?php
include('../includes/header.php');
include('../includes/navbar.php');
include('../config/db.php');

// Obtener el ID de la mascota desde la URL
$mascota_id = $_GET['id'];

// Consultar la base de datos para obtener los detalles de la mascota
$sql = "SELECT * FROM Mascotas WHERE mascota_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $mascota_id); // 's' para string
$stmt->execute();
$result = $stmt->get_result();

// Verificar si se encontró la mascota
if ($result->num_rows > 0) {
    $mascota = $result->fetch_assoc();
} else {
    echo "<p>La mascota no fue encontrada.</p>";
    exit();
}
?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Encuesta de Adopción para <?php echo $mascota['nombre']; ?></h2>
    <form action="" method="POST" id="encuestaForm">
        <input type="hidden" name="mascota_id" value="<?php echo $mascota['mascota_id']; ?>">
        <input type="hidden" name="nombre_mascota" value="<?php echo $mascota['nombre']; ?>">

        <div class="form-group">
            <label for="pregunta1">1. ¿Por qué quieres adoptar a esta mascota?</label>
            <textarea name="pregunta1" id="pregunta1" class="form-control" rows="3" required></textarea>
        </div>

        <div class="form-group">
            <label for="pregunta2">2. ¿Tienes experiencia cuidando mascotas?</label>
            <textarea name="pregunta2" id="pregunta2" class="form-control" rows="3" required></textarea>
        </div>

        <div class="form-group">
            <label for="pregunta3">3. ¿Cómo planeas cuidar de esta mascota?</label>
            <textarea name="pregunta3" id="pregunta3" class="form-control" rows="3" required></textarea>
        </div>

        <div class="form-group">
            <label for="pregunta4">4. ¿Tienes alguna preferencia en cuanto a la raza o tipo de mascota?</label>
            <textarea name="pregunta4" id="pregunta4" class="form-control" rows="3" required></textarea>
        </div>

        <div class="form-group">
            <label for="pregunta5">5. ¿Tienes otras mascotas en casa?</label>
            <textarea name="pregunta5" id="pregunta5" class="form-control" rows="3" required></textarea>
        </div>

        <div class="form-group">
            <label for="pregunta6">6. ¿Qué harías si esta mascota tiene necesidades especiales o problemas de salud?</label>
            <textarea name="pregunta6" id="pregunta6" class="form-control" rows="3" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Enviar Encuesta</button>
    </form>

    <!-- Mensaje de éxito (oculto por defecto) -->
    <div id="successMessage" class="alert alert-success mt-3" style="display:none;">
        Encuesta enviada exitosamente. Gracias por tu interés. Serás redirigido a la página principal.
    </div>
</div>

<script>
// Validación en el frontend
document.getElementById('encuestaForm').onsubmit = function(event) {
    event.preventDefault(); // Prevenir el envío del formulario para validación

    // Validar que todas las preguntas tengan respuesta
    const formElements = this.elements;
    let isValid = true;

    for (let i = 0; i < formElements.length; i++) {
        if (formElements[i].type === "textarea" && formElements[i].value.trim() === "") {
            isValid = false;
            alert('Por favor, completa todas las preguntas.');
            break;
        }
    }

    // Si el formulario es válido, mostrar mensaje de éxito y redirigir
    if (isValid) {
        // Mostrar mensaje de éxito
        document.getElementById('successMessage').style.display = 'block';

        // Redirigir a la página principal después de 3 segundos
        setTimeout(function() {
            window.location.href = 'index.php';  // Redirige a la página principal
        }, 3000);
    }
};
</script>

<?php
include('../includes/footer.php');
?>
