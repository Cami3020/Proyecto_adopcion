<?php
include('../../config/db.php');
include('../../includes/header-panel.php');
include('../../includes/navbar-panel.php');

// Verificar si se recibió el ID del usuario
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();

    if (!$usuario) {
        die("Usuario no encontrado.");
    }
} else {
    die("ID de usuario no especificado.");
}

// Procesar el formulario si se envió
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $rol = $_POST['rol'];

    $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, email = ?, rol = ? WHERE id = ?");
    $stmt->bind_param("sssi", $nombre, $correo, $rol, $id);

    if ($stmt->execute()) {
        echo "<script>alert('Usuario actualizado exitosamente.'); window.location.href='gestion_usuarios.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar el usuario.');</script>";
    }
}
?>

<div class="container mt-5">
    <h1>Editar Usuario</h1>
    <form method="POST">
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($usuario['nombre']); ?>" required>
        </div>
        <div class="form-group">
            <label for="correo">Correo:</label>
            <input type="email" name="correo" class="form-control" value="<?php echo htmlspecialchars($usuario['email']); ?>" required>
        </div>
        <div class="form-group">
            <label for="rol">Rol:</label>
            <select name="rol" class="form-control">
                <option value="admin" <?php echo $usuario['rol'] == 'admin' ? 'selected' : ''; ?>>Administrador</option>
                <option value="usuario" <?php echo $usuario['rol'] == 'usuario' ? 'selected' : ''; ?>>Usuario</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Guardar Cambios</button>
        <a href="gestion_usuarios.php" class="btn btn-secondary mt-3">Cancelar</a>
    </form>
</div>

<?php include('../../includes/footer.php'); ?>
