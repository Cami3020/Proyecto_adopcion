<?php
include('../../config/db.php');
include('../../includes/header-panel.php');
include('../../includes/navbar-panel.php');
// Procesar el formulario si se envió
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mascota_id = $_POST['mascota_id'];
    $nombre = $_POST['nombre'];
    $edad = $_POST['edad'];
    $raza = $_POST['raza'];
    $personalidad = $_POST['personalidad'];
    $detalles = $_POST['detalles'];
    $estado = $_POST['estado'];  // 1 para Disponible, 0 para Adoptada
    $refugio_id = $_POST['refugio_id'];  // Asumimos que es el ID de un refugio ya existente

    // Procesar la imagen de la mascota
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $foto = $_FILES['foto']['name'];
        $ruta = "../../img/" . basename($foto);
        move_uploaded_file($_FILES['foto']['tmp_name'], $ruta);
    } else {
        $foto = NULL;  // Si no se sube foto, se guarda NULL
    }

    // Depuración: Verificar los valores antes de ejecutar el INSERT
    echo "Nombre: $nombre<br>";
    echo "Edad: $edad<br>";
    echo "Raza: $raza<br>";
    echo "Personalidad: $personalidad<br>";
    echo "Foto: $foto<br>";
    echo "Estado: $estado<br>";
    echo "Detalles: $detalles<br>";
    echo "Refugio ID: $refugio_id<br>";

    // Preparar la consulta para insertar la nueva mascota
    $stmt = $conn->prepare("INSERT INTO mascotas (mascota_id, nombre, edad, raza, personalidad, foto, estado, detalles, refugio_id) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        die("Error preparando la consulta: " . $conn->error);
    }

    // Ajustar el bind_param con tipos correctos
    $stmt->bind_param("ssissssss", $mascota_id, $nombre, $edad, $raza, $personalidad, $foto, $estado, $detalles, $refugio_id);

    if ($stmt->execute()) {
        echo "<script>alert('Mascota agregada exitosamente.'); window.location.href='gestion_mascotas.php';</script>";
    } else {
        echo "Error en la consulta: " . $stmt->error;
    }
}

?>

<div class="container mt-5">
    <h1>Agregar Nueva Mascota</h1>

    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="mascota_id" class="form-label">ID</label>
            <input type="text" class="form-control" id="mascota_id" name="mascota_id" required>
        </div>
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" id="nombre" name="nombre" required>
        </div>
        <div class="mb-3">
            <label for="edad" class="form-label">Edad</label>
            <input type="number" class="form-control" id="edad" name="edad" required>
        </div>
        <div class="mb-3">
            <label for="raza" class="form-label">Raza</label>
            <input type="text" class="form-control" id="raza" name="raza" required>
        </div>
        <div class="mb-3">
            <label for="personalidad" class="form-label">Personalidad</label>
            <textarea class="form-control" id="personalidad" name="personalidad" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="foto" class="form-label">Foto</label>
            <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
        </div>
        <div class="mb-3">
            <label for="estado" class="form-label">Estado</label>
            <select class="form-control" id="estado" name="estado" required>
                <option value="1">Disponible</option>
                <option value="0">Adoptada</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="detalles" class="form-label">Detalles</label>
            <textarea class="form-control" id="detalles" name="detalles" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="refugio_id" class="form-label">Refugio</label>
            <input type="text" class="form-control" id="refugio_id" name="refugio_id" required>
        </div>
        <button type="submit" class="btn btn-primary">Agregar Mascota</button>
        <a href="gestion_mascotas.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<?php include('../../includes/footer.php'); ?>