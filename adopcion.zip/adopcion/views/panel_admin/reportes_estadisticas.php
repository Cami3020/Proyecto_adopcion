<?php include('../../includes/header-panel.php'); ?>
<?php include('../../includes/navbar-panel.php'); ?>

<div class="container my-5">
    <h1 class="display-4 text-center mb-4">Reporte de Estadísticas</h1>
    <p class="lead text-center mb-5">Visualiza estadísticas sobre adopciones, usuarios y mascotas disponibles.</p>

    <div class="row mb-5">
        <!-- Tarjeta de Mascotas Disponibles -->
        <div class="col-md-4">
            <div class="card text-white bg-primary mb-3 shadow-lg text-center">
                <div class="card-body">
                    <h5 class="card-title">Mascotas Disponibles</h5>
                    <p class="card-text" style="font-size: 2rem;">
                        <?php
                        include('../../config/db.php');
                        try {
                            $query = "SELECT COUNT(*) AS total FROM mascotas WHERE estado = 'Disponibles'";
                            $result = $conn->query($query);
                            $disponibles = $result->fetch_assoc();
                            echo $disponibles['total'];
                        } catch (Exception $e) {
                            echo "Error: " . $e->getMessage();
                        }
                        ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Tarjeta de Adopciones Realizadas -->
        <div class="col-md-4">
            <div class="card text-white bg-success mb-3 shadow-lg text-center">
                <div class="card-body">
                    <h5 class="card-title">Adopciones Realizadas</h5>
                    <p class="card-text" style="font-size: 2rem;">
                        <?php
                        try {
                            $query = "SELECT COUNT(*) AS total FROM mascotas WHERE estado = 'Adoptada'";
                            $result = $conn->query($query);
                            $adoptadas = $result->fetch_assoc();
                            echo $adoptadas['total'];
                        } catch (Exception $e) {
                            echo "Error: " . $e->getMessage();
                        }
                        ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Tarjeta de Usuarios Registrados -->
        <div class="col-md-4">
            <div class="card text-white bg-warning mb-3 shadow-lg text-center">
                <div class="card-body">
                    <h5 class="card-title">Usuarios Registrados</h5>
                    <p class="card-text" style="font-size: 2rem;">
                        <?php
                        try {
                            $query = "SELECT COUNT(*) AS total FROM usuarios";
                            $result = $conn->query($query);
                            $usuarios = $result->fetch_assoc();
                            echo $usuarios['total'];
                        } catch (Exception $e) {
                            echo "Error: " . $e->getMessage();
                        }
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráfico de Estadísticas -->
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-lg">
                <div class="card-body">
                    <h5 class="card-title text-center">Resumen Gráfico</h5>
                    <canvas id="statsChart" width="400" height="200"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Script de Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Obtener los datos de las tarjetas para el gráfico
    const mascotasDisponibles = <?php echo $disponibles['total']; ?>;
    const adopcionesRealizadas = <?php echo $adoptadas['total']; ?>;
    const usuariosRegistrados = <?php echo $usuarios['total']; ?>;

    // Crear el gráfico de barras
    const ctx = document.getElementById('statsChart').getContext('2d');
    const statsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Mascotas Disponibles', 'Adopciones Realizadas', 'Usuarios Registrados'],
            datasets: [{
                label: 'Estadísticas',
                data: [mascotasDisponibles, adopcionesRealizadas, usuariosRegistrados],
                backgroundColor: ['#007bff', '#28a745', '#ffc107'],
                borderColor: ['#0056b3', '#218838', '#e0a800'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
</script>

<?php include('../../includes/footer.php'); ?>
