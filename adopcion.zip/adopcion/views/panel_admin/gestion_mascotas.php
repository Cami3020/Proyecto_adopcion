<?php include('../../includes/header-panel.php'); ?>
<?php include('../../includes/navbar-panel.php'); ?>

<div class="container mt-5">
    <h1>Gestión de Mascotas</h1>
    <p>Añade, edita o elimina perfiles de mascotas en la base de datos.</p>

    <a href="agregar_mascota.php" class="btn btn-success mb-3">Agregar Nueva Mascota</a>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Raza</th>
                <th>Personalidad</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include('../../config/db.php');
            $stmt = $conn->query("SELECT * FROM mascotas");
            while ($mascota = $stmt->fetch_assoc()) {
            ?>
                <tr>
                    <td><?php echo $mascota['nombre']; ?></td>
                    <td><?php echo $mascota['raza']; ?></td>
                    <td><?php echo $mascota['personalidad']; ?></td>
                    <td><?php echo $mascota['estado'] == 'Disponible' ? 'Disponible' : 'Adoptada'; ?></td>
                    <td>
                        <a href="editar_mascota.php?mascota_id=<?php echo $mascota['mascota_id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                        <a href="eliminar_mascota.php?mascota_id=<?php echo $mascota['mascota_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta mascota?');">Eliminar</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php include('../../includes/footer.php'); ?>
