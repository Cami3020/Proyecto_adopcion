<?php
include('../../config/db.php');
include('../../includes/header-panel.php');
include('../../includes/navbar-panel.php');

// Verificar si se recibió el ID de la mascota
if (isset($_GET['mascota_id'])) {
    $id = intval($_GET['mascota_id']);
    $stmt = $conn->prepare("SELECT * FROM mascotas WHERE mascota_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $mascota = $result->fetch_assoc();

    if (!$mascota) {
        die("Mascota no encontrada.");
    }
} else {
    die("ID de mascota no especificado.");
}

// Procesar el formulario si se envió
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $edad = intval($_POST['edad']);
    $raza = $_POST['raza'];
    $personalidad = $_POST['personalidad'];
    $estado = $_POST['estado'];
    $detalles = $_POST['detalles'];
    $refugio_id = intval($_POST['refugio_id']);

    $conn->begin_transaction();  // Iniciar la transacción

    $stmt = $conn->prepare("UPDATE mascotas SET nombre = ?, edad = ?, raza = ?, personalidad = ?, estado = ?, detalles = ?, refugio_id = ? WHERE mascota_id = ?");
    $stmt->bind_param("sissssss", $nombre, $edad, $raza, $personalidad, $estado, $detalles, $refugio_id, $id);

    if ($stmt->execute()) {
        $conn->commit();  // Confirmar la transacción
        echo "<script>alert('Mascota actualizada exitosamente.'); window.location.href='gestion_mascotas.php';</script>";
    } else {
        $conn->rollback();  // Revertir la transacción si falla
        echo "<script>alert('Error al actualizar la mascota.');</script>";
        echo "Error en la consulta: " . $stmt->error;
    }


}
?>

<div class="container mt-5">
    <h1>Editar Mascota</h1>
    <form method="POST">
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($mascota['nombre']); ?>" required>
        </div>
        <div class="form-group">
            <label for="edad">Edad:</label>
            <input type="number" name="edad" class="form-control" value="<?php echo htmlspecialchars($mascota['edad']); ?>" required>
        </div>
        <div class="form-group">
            <label for="raza">Raza:</label>
            <input type="text" name="raza" class="form-control" value="<?php echo htmlspecialchars($mascota['raza']); ?>" required>
        </div>
        <div class="form-group">
            <label for="personalidad">Personalidad:</label>
            <textarea name="personalidad" class="form-control" rows="3" required><?php echo htmlspecialchars($mascota['personalidad']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="estado">Estado:</label>
            <select name="estado" class="form-control" required>
                <option value="Disponible" <?php echo $mascota['estado'] == 'Disponible' ? 'selected' : ''; ?>>Disponible</option>
                <option value="Adoptada" <?php echo $mascota['estado'] == 'Adoptada' ? 'selected' : ''; ?>>Adoptada</option>
            </select>
        </div>
        <div class="form-group">
            <label for="detalles">Detalles:</label>
            <textarea name="detalles" class="form-control" rows="3" required><?php echo htmlspecialchars($mascota['detalles']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="refugio_id">ID del Refugio:</label>
            <input type="text" name="refugio_id" class="form-control" value="<?php echo htmlspecialchars($mascota['refugio_id']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Guardar Cambios</button>
        <a href="gestion_mascotas.php" class="btn btn-secondary mt-3">Cancelar</a>
    </form>
</div>

<?php include('../../includes/footer.php'); ?>
