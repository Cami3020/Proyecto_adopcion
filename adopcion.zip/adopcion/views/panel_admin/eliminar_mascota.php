<?php
include('../../config/db.php');

if (isset($_GET['mascota_id'])) {
    $mascota_id = $_GET['mascota_id'];

    $stmt = $conn->prepare("DELETE FROM mascotas WHERE mascota_id = ?");
    $stmt->bind_param("s", $mascota_id);

    if ($stmt->execute()) {
        echo "<script>alert('Mascota eliminada exitosamente.'); window.location.href='gestion_mascotas.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar la mascota.'); window.location.href='gestion_mascotas.php';</script>";
    }
} else {
    echo "<script>alert('ID de mascota no especificado.'); window.location.href='gestion_mascotas.php';</script>";
}
?>
