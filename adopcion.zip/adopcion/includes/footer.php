<footer>
    <p>&copy; 2024 Adopción Responsable de Mascotas</p>
    <p>Todos los derechos reservados.</p>
</footer>
